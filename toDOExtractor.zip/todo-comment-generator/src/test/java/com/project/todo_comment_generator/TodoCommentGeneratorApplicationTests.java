package com.project.todo_comment_generator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoCommentGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
